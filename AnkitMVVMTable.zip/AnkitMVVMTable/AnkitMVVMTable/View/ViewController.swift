//
//  ViewController.swift
//  AnkitMVVMTable
//
//  Created by Ankit Soni on 17/02/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    let viewModel = EmployeeViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.vc = self
    }

}


extension ViewController : UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.model?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tblView.dequeueReusableCell(withIdentifier: "EmployeeTableViewCell", for: indexPath) as? EmployeeTableViewCell else{
            return UITableViewCell.init()
        }
        cell.setData(data : viewModel.model?[indexPath.row])
        return cell
    }
    
}
