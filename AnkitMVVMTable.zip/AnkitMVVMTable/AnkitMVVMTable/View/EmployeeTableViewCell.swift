//
//  EmployeeTableViewCell.swift
//  AnkitMVVMTable
//
//  Created by Ankit Soni on 17/02/21.
//

import UIKit

class EmployeeTableViewCell: UITableViewCell {
    
    @IBOutlet weak var txtName: UILabel!
    @IBOutlet weak var txtSalary: UILabel!
    @IBOutlet weak var txtRole: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func setData(data : EmployeeModel?)
    {
        if let data = data
        {
            self.txtName.text = data.name
            self.txtRole.text = data.role
            self.txtSalary.text = "\(String(describing: data.salary!))"
        }
        
    }
}
