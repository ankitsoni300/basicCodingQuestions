//
//  ApiUrls.swift
//  AnkitMVVMTable
//
//  Created by Ankit Soni on 17/02/21.
//

import Foundation

struct ApiUrls {
    static let employeeUrl = "http://demo0333988.mockable.io/Employees"
}
