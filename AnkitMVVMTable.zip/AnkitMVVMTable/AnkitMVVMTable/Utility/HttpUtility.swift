//
//  HttpUtility.swift
//  AnkitMVVMTable
//
//  Created by Ankit Soni on 17/02/21.
//

import Foundation

struct HttpUtility {
    
    func getData<T : Codable>(requestUrl : URL, resultType : T.Type, completion : @escaping((Result<T, Error>) -> ())){
        URLSession.shared.dataTask(with: requestUrl) { (data, response, error) in
            if error == nil && data?.count != 0 && response != nil{
                guard let data = data else {
                    return
                }
                do {
                    let decode = JSONDecoder()
                    let result = try decode.decode(T.self, from: data)
                    completion(.success(result))
                } catch let error {
                    completion(.failure(error))
                }
            }
        }.resume()
    }
    
    func postData<T : Codable>(requestUrl : URL, requestBody : Data, resultType : T.Type, completion : @escaping((Result<T?, Error>) -> ())){
        
        var request = URLRequest(url: requestUrl)
        request.httpBody = requestBody
        request.httpMethod = "post"
        request.addValue("application/json", forHTTPHeaderField: "content-type")
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if error == nil && data?.count != 0 && response != nil{
                guard let data = data else {
                    return
                }
                do {
                    let decode = JSONDecoder()
                    let result = try decode.decode(T.self, from: data)
                    completion(.success(result))
                } catch let error {
                    completion(.failure(error))
                }
            }
        }.resume()
    }
}
