//
//  EmployeeViewModel.swift
//  AnkitMVVMTable
//
//  Created by Ankit Soni on 17/02/21.
//

import Foundation


class EmployeeViewModel {
    
    var model : [EmployeeModel]?
    weak var vc : ViewController?
    
    init(employee : [EmployeeModel]? = nil) {
        self.model = employee
        getData()
    }

    func getData()
    {
        let empDataResouce = EmployeeDataResource()
        
        empDataResouce.getEmployeeData { [weak self] (employees) in
            self?.model = employees
            DispatchQueue.main.async {
                self?.vc?.tblView.reloadData()
            }
        }
    }
    
}
