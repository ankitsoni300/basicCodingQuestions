//
//  EmployeeModel.swift
//  AnkitMVVMTable
//
//  Created by Ankit Soni on 17/02/21.
//

import Foundation

struct EmployeeModel : Codable {
    var id : Int?
    var name : String?
    var role : String?
    var joining_date : String?
    var dep_id : Int?
    var salary : Int?
    var workPhone : String?
    
    enum CodingKeys : String, CodingKey {
        case id = "id"
        case name = "name"
        case role = "role"
        case joining_date = "joining_date"
        case dep_id = "dep_id"
        case salary = "salary"
        case workPhone = "workPhone"
    }
}
