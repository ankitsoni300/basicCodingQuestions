//
//  EmployeeDataResource.swift
//  AnkitMVVMTable
//
//  Created by Ankit Soni on 17/02/21.
//

import Foundation

struct EmployeeDataResource {
    
    func getEmployeeData(completion : @escaping(([EmployeeModel]?)->())){
        let httpUtility = HttpUtility()
        guard let url = URL(string: ApiUrls.employeeUrl) else{
            return
        }
        httpUtility.getData(requestUrl: url, resultType: [EmployeeModel].self) { (result) in
            switch result{
            case .success(let response):
                completion(response)
            case .failure(_): 
                completion(nil)
            }
        }
    }
    
}
